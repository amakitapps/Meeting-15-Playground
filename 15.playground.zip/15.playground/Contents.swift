// Name: files

import Foundation

//extension FileManager {
//  static var documentDirectoryURL: URL {
//
//  return `default`.urls(for: .documentDirectory, in: .userDomainMask)[0]
//  // the tickmarks `` allow us to use a keyword without generating errors
//
//  //this is the default location of the Documents directory; note the location listed at right when running the sandbox. It is an array, so we use [0] to specify.
//
//  //Every time that we want to reference a file location, we would have to use that whole block. Ick. So we put it inside a var as a computed property.
//  }
//
////We want to wrap the computed property in an extension. Now we can just call it.
//}

FileManager.documentDirectoryURL //now it's much easier to call it

//Press Command 1 to browse files.
//Add an Extensions folder underneath Sources.
//Inside Extensions, new file. Swift file called Filemanager.swift. 
//Cut out extension above and move it to the new file.
//Must call the extension file. Add keyword pubic in extension file. 
//May need to kill Xcode and reload to make it load without errors.

FileManager.documentDirectoryURL.path
//This allows you to see the path instead of a folder button when you use QuickLook.

//let's put some stuff in the file

//making the WHERE
let mysteryDataURL = URL(fileURLWithPath: "mystery", relativeTo: FileManager.documentDirectoryURL) //we called it!

mysteryDataURL.path //this gives us the path with just mystery

let stringURL = FileManager.documentDirectoryURL.appendingPathComponent("string").appendingPathExtension("text")
//this adds this filename to the directory

stringURL.path //this gives us the path with string.text

//Note that we have not yet uploaded or put data anywhere. That will be next time.

// CHALLENGE -------------------------

let challengeString: String
let challengeStringURL: URL

//We want to store a string in challengeString.
//We want to initialize a file.
//We want to append "text" to the end.

challengeString = "Who are you?"

challengeStringURL = URL(fileURLWithPath: challengeString, relativeTo: FileManager.documentDirectoryURL).appendingPathExtension("text")

//We can run it to see the path.

//We can do this if it represents a file:
challengeStringURL.lastPathComponent //returns the last path component of the URL--we see the filename!
challengeStringURL.path //we see the whole path

// ADDITIONS FROM 6-28-2019

// UInt8 = 8 bit unsigned integer. A byte is 8 bits.
// With 8 bits, the value of ranges per byte is 2^8th power (0-255)

// Base 10: Decimal - range of UInt8 (0-255)
// Base 2: Binary - 0b100100110111110000 (binary code for a byte) - can use underscores in Swift 0b1001_1101_1111_0000 to break it into nybbles
// Base 16: Hexadecimal or Hex - 0x9DF0

let mysteryBytes: [UInt8] = [
    240,             159,            152,               184,
    240,             159,            152,               185,
    0b1111_0000,    0b1001_1111,    0b1001_1000,        186,
    0xF0,           0x9F,           0x98,               187
]

//To save it, we will make a new instance of the data
let mysteryData = Data(_: mysteryBytes)

try mysteryData.write(to: mysteryDataURL) //established it last week

//we've written it; now let's read it back
let savedMysteryData = try Data(contentsOf: mysteryDataURL)

//and let's look at it
let savedMysteryBytes = Array(savedMysteryData)

//if we want to double-check....
savedMysteryBytes == mysteryBytes
savedMysteryData  == mysteryData

//now let's look at it with an extension; control-click on the file path above to see it
try mysteryData.write(to: mysteryDataURL.appendingPathExtension("text"))
// we see four emojis in a text file; each emoji is four bytes (one row)

//now let's read the whole string back into Swift
let string = String(data: savedMysteryData, encoding: .utf8)!

//next time we will look at an easier way to do this. 
